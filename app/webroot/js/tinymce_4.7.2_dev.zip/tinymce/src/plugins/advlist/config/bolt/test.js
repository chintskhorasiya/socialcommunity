configure({
  configs: [
    '../../../../../config/bolt/test.js'
  ]
});
