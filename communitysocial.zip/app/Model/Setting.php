<?php
App::uses('AppModel', 'Model');
class Setting extends AppModel {
    
    public $name = 'Setting';
    
}