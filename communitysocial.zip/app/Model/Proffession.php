<?php
App::uses('AppModel', 'Model');

class Proffession extends AppModel
{    
    public $name = 'Proffession';    
}