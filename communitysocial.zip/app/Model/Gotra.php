<?php
App::uses('AppModel', 'Model');

class Gotra extends AppModel
{    
    public $name = 'Gotra';    
}