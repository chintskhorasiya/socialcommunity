<?php
App::uses('AppModel', 'Model');

class State extends AppModel
{    
    public $name = 'State';
}