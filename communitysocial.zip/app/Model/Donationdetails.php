<?php
App::uses('AppModel', 'Model');
class Donationdetails extends AppModel {
    
    public $name = 'Donationdetails';
    
}