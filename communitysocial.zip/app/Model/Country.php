<?php
App::uses('AppModel', 'Model');

class Country extends AppModel
{    
    public $name = 'Country';
}