<?php
App::uses('AppModel', 'Model');

class Relation extends AppModel
{    
    public $name = 'Relation';    
}