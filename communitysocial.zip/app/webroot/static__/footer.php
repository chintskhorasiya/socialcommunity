<!-- Footer -->

<section class="footer-b">

<header class="panel-heading">

<div id="footer">

	<!-- You can change the copyright line for your own -->

	<a href="#" target="_blank" class="poweredby">&copy; <?php echo date("Y")?> <?=SITE_NAME?> Administrator | Design & Developed by Seawind Solution Pvt. Ltd. </a>

	<div style="clear:both;"></div>

</div>

</header> <!-- End #footer -->

</section>



