<?php 
session_start();

include('configure/configure.php');

include('auth.php');

//accessPermission('1,5','page');

$error_message = '';

$error = 0;	

if(count($_POST) > 0)

{

	

	if(trim($_POST['store_fullname']) == '')

	{

		$store_fname_error = '<label class="alert-danger fade in">This field is required.</label>';	

		$error = 1;

	}

	 

	

	if(trim($_POST['store_password']) == '')

	{

		$store_password_error = '<label class="alert-danger fade in">This field is required.</label>';	

		$error = 1;

	}

	if(strlen(trim($_POST['store_password'])) < 8)

	{

		$store_password_error = '<label class="alert-danger fade in">Password length should be greater than 7.</label>';	

		$error = 1;

	}

	

	 

	if(!validate_email($_POST['store_email']))

	{

		$store_email_error = '<label class="alert-danger fade in">Email address is not valid.</label>';	

		$error = 1;

	}

	

	if(store_duplicate_email(trim($_POST['store_email'])) > 0)

	{

		$store_email_error = '<label class="alert-danger fade in">Email Already Exists.</label>';	

		$error = 1;

	}

	

	if(trim($_POST['store_name']) == '')

	{

		$store_name_error = '<label class="alert-danger fade in">This field is required.</label>';	

		$error = 1;

	}

	if(store_duplicate_name(trim($_POST['store_name'])) > 0)

	{

		$store_name_error = '<label class="alert-danger fade in">Store Name already exists.</label>';	

		$error = 1;

	}

	

	if(trim($_POST['store_url']) == '')

	{

		$store_url_error = '<label class="alert-danger fade in">This field is required.</label>';	

		$error = 1;

	}

	else if(store_duplicate_url(trim($_POST['store_url'])) > 0)

	{

		$store_url_error = '<label class="alert-danger fade in">Store Url already exists.</label>';	

		$error = 1;

	}

	if(!store_valid_url(trim($_POST['store_url'])))

	{

		$store_url_error = '<label class="alert-danger fade in">Store Url not valid.</label>';	

		$error = 1;

	}

	

	if($_FILES['store_icon']['name'] == '')

	{

		$store_icon_error = '<label class="alert-danger fade in">This field is required.</label>';	

		$error = 1;

	}

	

	if(trim($_POST['store_address']) == '')

	{

		$store_address_error = '<label class="alert-danger fade in">This field is required.</label>';	

		$error = 1;

	}

	if(trim($_POST['store_phone']) == '')

	{

		$store_phone_error = '<label class="alert-danger fade in">This field is required.</label>';	

		$error = 1;

	}

	if(trim($_POST['store_country']) == '' || trim($_POST['store_country']) == '0')

	{

		$store_country_error = '<label class="alert-danger fade in">This field is required  for country. </label>';	

		$error = 1;

	}

	if(trim($_POST['store_state']) == '' || trim($_POST['store_state']) == '0')

	{

		$store_state_error = '<label class="alert-danger fade in">This field is required  for state. </label>';	

		$error = 1;

	}

	if(trim($_POST['store_city']) == '' || trim($_POST['store_city']) == '0')

	{

		$store_city_error = '<label class="alert-danger fade in">This field is required  for City. </label>';	

		$error = 1;

	}

	

	if($error == 1)

	{

		$error_message = ' <div>

                                <label class="alert alert-block alert-danger fade in col-lg-11 col-sm-6">Please fillup all required information.</label>

                            </div>';

	}

	else

	{

			

		if($_FILES['store_icon']['name'] != '')

		{

			$image_name = upload_image($_FILES['store_icon'],STOREICONPATH,STOREICON_THUMBPATH,'156','106');

			if($image_name) 

			{

				$_POST['store_icon'] = $image_name;	

			}

		}

		

		$_POST['store_created_date']  = $current_date;

		$_POST['store_modified_date'] = $current_date;

		$_POST['store_pwd'] 		  = set_password($_POST['store_password']);

		$_POST['store_password'] 	  = encrypt_password($_POST['store_password']);

		

		

		

		$insert_id = insert_data('store',$_POST);

		if($insert_id)

		{

			send_store_registration_email($insert_id);

			header('location:stores.php');

			exit;

		}

		else

		{

			echo mysql_error();

		}

	}	

}

$styles 	 = include_styles('bootstrap.min.css,assets/jquery-ui/jquery-ui-1.10.1.custom.min.css,bootstrap-reset.css,font-awesome.css,jquery-jvectormap-1.2.2.css,css3clock/css/style.css,morris-chart/morris.css,DT_bootstrap.css,demo_page.css,demo_table.css,jquery.wysiwyg.css,style.css,style-responsive.css');

$javascripts = include_js('lib/jquery.js,lib/jquery-1.8.3.min.js,bootstrap.min.js,accordion-menu/jquery.dcjqaccordion.2.7.js,scrollTo/jquery.scrollTo.min.js,nicescroll/jquery.nicescroll.js,scripts.js,gritter/gritter.js,jquery.MultiFile.js,acco-nav.js');

?>
<?=DOCTYPE;?>
<?=XMLNS;?>
<head>
<?=CONTENTTYPE;?>
<title>Store Settings</title>
<?=$styles?>
<?=$javascripts?>
<script language="javascript" type="text/javascript">

$(document).ready(function(){

		var ajax_state_url = 'ajax-state-dropdown.php';

		$('.store_country').change(function(){

				

				var state = $(this).val(); 

				$.post(ajax_state_url,{state:state}, function(data) {

					  if(data != '')

						  $('.store_state').html(data);

		

					  $('.store_state').trigger('change');

				});

		});

		var ajax_city_url = 'ajax-city-dropdown.php';

		$('.store_state').change(function(){

				

				var state = $(this).val(); 

				var country = $('.store_country').val(); 

				

				$.post(ajax_city_url,{state:state,country:country}, function(data) {

					  if(data != '')

						  $('.store_city').html(data);

				});

		});

		

});

</script>
<style>
.form-control {
	width: 59%;
	font-size: 13px;
}
select.input-lg, .input-lg {
	height: auto;
	padding: 6px 8px;
}
</style>

<!-- Initiate tablesorter script -->

</head>

<body>
<section id="container"> 
  
  <!--header start-->
  
  <?php  	include('header.php');?>
  
  <!--header end--> 
  
  <!--sidebar start-->
  
  <?php include('sidebar.php');?>
  
  <!--sidebar end--> 
  
  <!--main content start-->
  
  <section id="main-content">
    <section class="wrapper">
      <div class="row">
        <div class="col-lg-12">
          <section class="panel">
            <header class="panel-heading btn-primary"> Enable/Disable PriceYak features </header>
            <div class="panel-body">
              <div class="position-center">
                 
                <form role="form" enctype="multipart/form-data" method="post" action="store-add.php">
                  <?=$error_message;?>
                  <div class="form-group">  
                      <div class="checkbox">
                        <label>
                          <input type="checkbox" name="enable-repricing" value="1" >
                          Enable Repricing </label>
						  <span class="h-tooltip" aria-hidden="true">?</span>
						  <div class="tooltip"><span>Enables automatic updating of your price and quantity based on source availability. You are only charged for this service when this box is checked. If you turn this off, you may sell items that are out-of-stock or priced too expensively at the source.</span></div>
                      </div>
                      <div class="checkbox">
                        <label>
                          <input  type="checkbox" name="enable-autoOrdering" value="2">
                          Enable AutoOrdering </label>
						  <span class="h-tooltip" aria-hidden="true">?</span>
						  <div class="tooltip"><span>AutoOrdering automatically places orders at the source retailer within minutes of receiving a sale on your listing. You must also add fulfillment account(s) for AutoOrdering to work.</span></div>
                     
                      </div>
                   
                  </div>
                  <input type="submit" class="btn btn-info" value="Save Settings">
                </form>
              </div>
            </div>
          </section>
        </div>
      </div>
    </section>
  </section>
  
  <!--main content end--> 
  
  <!--right sidebar start-->
  
  <div class="right-sidebar">
    <div class="search-row">
      <input type="text" placeholder="Search" class="form-control">
    </div>
  </div>
  
  <!--right sidebar end--> 
  
</section>
</body>
</html>